# 3D transforms in motion

Use this reference for animated X/Y tilt, card flips, depth, or perspective. Load `figma-use` and `figma-use-motion`, then load `figma-3d-transforms` when available to establish the static scene, projection, and pivots before writing keyframes.

## Availability

If `node.transform3d` reads back `undefined`, the 3D transform capability isn't enabled in this environment. Don't silently produce nothing — tell the user 3D transforms aren't available here. `scene3d` exists only on FRAME, COMPONENT, and INSTANCE containers; `null` there means no scene is configured. An `undefined` `scene3d` on another node type does not indicate that 3D is unavailable.

If writing a 3D track throws `Unsupported keyframe field property`, 3D transforms aren't enabled in this environment. Tell the user rather than silently substituting a 2D approximation. Stop the unsupported operation instead of retrying, and preserve existing animation. Ordinary 2D keyframes remain available when motion is enabled without 3D.

## Keyframe fields

These fields use ordinary manual keyframe tracks with `FLOAT` values:

| Field | Unit | Notes |
|---|---|---|
| `TRANSFORM_3D_ROTATION_X` | degrees | Positive tilts the top edge away from the viewer. |
| `TRANSFORM_3D_ROTATION_Y` | degrees | Rotation about the vertical axis. |
| `TRANSFORM_3D_ROTATION_Z` | degrees | In-plane rotation after X and Y, matching the static 3D pose. |
| `TRANSFORM_3D_TRANSLATION_Z` | pixels | Depth; negative values are valid. |
| `SCENE_3D_PERSPECTIVE` | pixels | Nonnegative perspective on a FRAME, COMPONENT, or INSTANCE. |

Use these exact names, including the `TRANSFORM_3D_` prefix. The rotations use degrees without the sign inversion of ordinary 2D `ROTATION`.

Establish a `FIXED_ORDER` pose before animating; imported `FREEFORM` transforms are not supported for 3D keyframing. Rotation and depth tracks compose with the resting pose, so read it before choosing values. A neutral rotation keyframe of `0` retains the resting angle. Keep perspective on the container above the transformed object, following the static skill's scene rules.

`backfaceVisible`, `visible`, `preserve3d`, and `transformOrigin` are static properties, not keyframe fields.

## Add a turn to an existing pose

For a node with its static scene already configured, add a Y-axis half-turn over 0.6 seconds:

```javascript
const node = await figma.getNodeByIdAsync('123:456');
node.applyManualKeyframeTrack(
  { type: 'PROPERTY', name: 'TRANSFORM_3D_ROTATION_Y' },
  {
    keyframes: [
      { timelinePosition: 0, value: { type: 'FLOAT', value: 0 } },
      {
        timelinePosition: 0.6,
        value: { type: 'FLOAT', value: 180 },
        easing: { type: 'EASE_IN_AND_OUT' },
      },
    ],
  },
);
return { nodeId: node.id, tracks: node.manualKeyframeTracks };
```

This adds or replaces the Y rotation track without rewriting unrelated tracks. When editing an existing track, preserve its identity and keyframe IDs as described in [motion-patterns.md](motion-patterns.md#manual-keyframes).

Read back the tracks and follow the main motion skill's video verification guidance when the result is not self-evident. A screenshot only shows the resting state.
